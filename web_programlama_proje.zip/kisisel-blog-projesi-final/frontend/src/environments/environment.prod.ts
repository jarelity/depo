export const environment = {
  production: true,
  apiUrl: 'https://YOUR-BACKEND-URL.com/api',
};
